# File Sharing Service
A lightweight internal Flask-based file-sharing service, containerized with Docker.