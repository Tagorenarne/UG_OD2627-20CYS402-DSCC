import os
from flask import Flask, request, send_from_directory, jsonify

app = Flask(__name__)

UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "/app/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.route("/")
def home():
    return jsonify({
        "message": "Internal File Sharing Service",
        "env": os.environ.get("APP_ENV", "development")
    })

@app.route("/files", methods=["GET"])
def list_files():
    files = os.listdir(UPLOAD_DIR)
    return jsonify({"files": files})

@app.route("/files/<filename>", methods=["GET"])
def get_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)

@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400
    file = request.files["file"]
    file.save(os.path.join(UPLOAD_DIR, file.filename))
    return jsonify({"message": f"{file.filename} uploaded successfully"})

if __name__ == "__main__":
    port = int(os.environ.get("APP_PORT", 8000))
    app.run(host="0.0.0.0", port=port)