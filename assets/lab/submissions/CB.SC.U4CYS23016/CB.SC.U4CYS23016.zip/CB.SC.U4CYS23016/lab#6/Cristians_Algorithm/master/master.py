"""Cristian's algorithm - master / time server.

Keeps a logical clock (system time + CLOCK_OFFSET) and returns it whenever a
client sends TIME_REQUEST.  The operating-system clock is never modified.

Protocol: one newline-terminated JSON message per request / reply over TCP.
    client -> master : {"type": "TIME_REQUEST", "id": <client id>}
    master -> client : {"type": "MASTER_TIME", "time": <epoch secs>}

Artificial delay (for the network-delay experiments):
    ARTIFICIAL_DELAY_MS  delay in ms applied to each affected direction
    DELAY_MODE           both     - request AND response path delayed (symmetric)
                         request  - only the request path (before the clock is read)
                         response - only the response path (after the clock is read)
"""
import json
import os
import socketserver
import time
from datetime import datetime, timezone

PORT = int(os.environ.get("MASTER_PORT", "5000"))
CLOCK_OFFSET = float(os.environ.get("CLOCK_OFFSET", "0"))
DELAY_MS = float(os.environ.get("ARTIFICIAL_DELAY_MS", "0"))
DELAY_MODE = os.environ.get("DELAY_MODE", "both")

if DELAY_MODE not in ("both", "request", "response"):
    raise SystemExit(f"DELAY_MODE must be both, request or response (got {DELAY_MODE!r})")

REQUEST_DELAY = DELAY_MS / 1000 if DELAY_MODE in ("both", "request") else 0.0
RESPONSE_DELAY = DELAY_MS / 1000 if DELAY_MODE in ("both", "response") else 0.0


def now():
    return time.time() + CLOCK_OFFSET


def fmt(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%H:%M:%S.%f")[:-3]


def log(msg):
    print(f"[master] {msg}", flush=True)


class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        line = self.rfile.readline()
        if not line:
            return
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            return
        if msg.get("type") != "TIME_REQUEST":
            return

        client = msg.get("id", self.client_address[0])
        log(f"TIME_REQUEST from {client} ({self.client_address[0]})")

        time.sleep(REQUEST_DELAY)        # delay on the request path
        master_time = now()              # <- the time the client will receive
        time.sleep(RESPONSE_DELAY)       # delay on the response path
        self.wfile.write((json.dumps({"type": "MASTER_TIME", "time": master_time}) + "\n").encode())

        log(f"MASTER_TIME = {fmt(master_time)} sent to {client}")


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    log(f"logical clock offset {CLOCK_OFFSET:+.3f} sec, clock now {fmt(now())}")
    log(f"artificial delay {DELAY_MS:g} ms, mode '{DELAY_MODE}' "
        f"(request path {REQUEST_DELAY * 1000:g} ms, response path {RESPONSE_DELAY * 1000:g} ms)")
    log(f"listening on port {PORT}")
    with Server(("0.0.0.0", PORT), Handler) as server:
        server.serve_forever()
