"""Cristian's algorithm - client.

Keeps a logical clock (system time + a configurable offset), asks the master
for its time once, and corrects the logical clock with
    synchronized time = master time + RTT / 2
The operating-system clock is never modified.

MASTER_OFFSET is used ONLY to measure the final error (all containers share the
host's system clock, so the master's true time is known); the algorithm itself
never uses it.
"""
import json
import os
import socket
import sys
import time
from datetime import datetime, timezone

CLIENT_ID = os.environ.get("CLIENT_ID", "client")
CLOCK_OFFSET = float(os.environ.get("CLOCK_OFFSET", "0"))
MASTER_HOST = os.environ.get("MASTER_HOST", "clock-master")
MASTER_PORT = int(os.environ.get("MASTER_PORT", "5000"))
MASTER_OFFSET = float(os.environ.get("MASTER_OFFSET", "0"))      # evaluation only
MASTER_TIMEOUT = float(os.environ.get("MASTER_TIMEOUT", "30"))   # wait for the master to come up
REQUEST_TIMEOUT = float(os.environ.get("REQUEST_TIMEOUT", "10"))


class LogicalClock:
    """System time shifted by an adjustable offset (seconds)."""

    def __init__(self, offset):
        self.offset = offset

    def at(self, system_time):
        return system_time + self.offset

    def now(self):
        return self.at(time.time())

    def set_to(self, value, at_system_time):
        """Make the logical clock read `value` at the instant `at_system_time`."""
        self.offset = value - at_system_time


def fmt(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%H:%M:%S.%f")[:-3]


def ms(seconds):
    return f"{seconds * 1000:.3f} ms"


def connect_to_master():
    deadline = time.time() + MASTER_TIMEOUT
    while True:
        try:
            return socket.create_connection((MASTER_HOST, MASTER_PORT), timeout=REQUEST_TIMEOUT)
        except OSError as exc:        # master container may still be starting
            if time.time() >= deadline:
                raise SystemExit(f"[{CLIENT_ID}] master unreachable ({exc}) - clock left unchanged")
            time.sleep(0.5)


def main():
    clock = LogicalClock(CLOCK_OFFSET)
    initial_clock = clock.now()

    with connect_to_master() as s:
        t1_sys = time.time()                       # T1: immediately before the request
        t1 = clock.at(t1_sys)
        s.sendall((json.dumps({"type": "TIME_REQUEST", "id": CLIENT_ID}) + "\n").encode())
        reply = s.makefile("rb").readline()
        t2_sys = time.time()                       # T2: immediately after the response
        t2 = clock.at(t2_sys)

    master_time = json.loads(reply)["time"]
    rtt = t2 - t1                                  # offset cancels in the difference
    delay = rtt / 2                                # symmetric-delay assumption
    corrected = master_time + delay                # synchronized time at T2
    clock.set_to(corrected, at_system_time=t2_sys)

    true_master = t2_sys + MASTER_OFFSET           # evaluation oracle (see module docstring)
    initial_error = t2 - true_master
    final_error = corrected - true_master

    print("========== CRISTIAN'S ALGORITHM ==========\n")
    print(f"Client ID       : {CLIENT_ID}")
    print(f"Initial Clock   : {fmt(initial_clock)}\n")
    print(f"T1              : {fmt(t1)}")
    print(f"Master Time     : {fmt(master_time)}")
    print(f"T2              : {fmt(t2)}\n")
    print(f"RTT             : {ms(rtt)}")
    print(f"Estimated Delay : {ms(delay)}\n")
    print(f"Corrected Clock : {fmt(corrected)}")
    print(f"Initial Error   : {initial_error * 1000:+.3f} ms")
    print(f"Final Error     : {final_error * 1000:+.3f} ms", flush=True)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as exc:
        sys.exit(f"[{CLIENT_ID}] synchronization failed: {exc}")
    while True:                                    # keep the container (and logical clock) alive
        time.sleep(3600)
