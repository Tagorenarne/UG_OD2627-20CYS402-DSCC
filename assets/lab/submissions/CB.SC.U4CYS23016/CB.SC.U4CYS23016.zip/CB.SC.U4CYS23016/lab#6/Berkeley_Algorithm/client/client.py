"""Berkeley algorithm - client node.

Keeps an independent logical clock (system time + a configurable offset),
answers the master's CLOCK_REQUEST and applies the CORRECTION it receives.

Protocol: one newline-terminated JSON message per request / reply over TCP.
    master -> client : {"type": "CLOCK_REQUEST"}
    client -> master : {"type": "CLOCK_REPLY", "id": ..., "clock": <epoch secs>}
    master -> client : {"type": "CORRECTION", "value": <secs>}
    client -> master : {"type": "ACK", "id": ..., "before": ..., "after": ...}
"""
import json
import os
import socketserver
import threading
import time
from datetime import datetime, timezone

CLIENT_ID = os.environ.get("CLIENT_ID", "client")
CLOCK_OFFSET = float(os.environ.get("CLOCK_OFFSET", "0"))
PORT = int(os.environ.get("CLIENT_PORT", "5000"))


class LogicalClock:
    """System time shifted by an adjustable offset (seconds)."""

    def __init__(self, offset):
        self._offset = offset
        self._lock = threading.Lock()

    def now(self):
        with self._lock:
            return time.time() + self._offset

    def adjust(self, delta):
        """Apply a correction; returns (clock before, clock after)."""
        with self._lock:
            before = time.time() + self._offset
            self._offset += delta
            return before, time.time() + self._offset


clock = LogicalClock(CLOCK_OFFSET)


def fmt(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%H:%M:%S.%f")[:-3]


def log(msg):
    print(f"[{CLIENT_ID}] {msg}", flush=True)


class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        line = self.rfile.readline()
        if not line:
            return
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            return

        kind = msg.get("type")
        if kind == "CLOCK_REQUEST":
            value = clock.now()
            log(f"CLOCK_REQUEST received -> replying {fmt(value)}")
            reply = {"type": "CLOCK_REPLY", "id": CLIENT_ID, "clock": value}
        elif kind == "CORRECTION":
            delta = float(msg["value"])
            before, after = clock.adjust(delta)
            log(f"CORRECTION received: {delta:+.3f} sec")
            log(f"  clock before sync : {fmt(before)}")
            log(f"  clock after sync  : {fmt(after)}")
            reply = {"type": "ACK", "id": CLIENT_ID, "before": before, "after": after}
        else:
            return
        self.wfile.write((json.dumps(reply) + "\n").encode())


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    log(f"configured offset {CLOCK_OFFSET:+.3f} sec, initial clock {fmt(clock.now())}")
    log(f"listening on port {PORT}")
    with Server(("0.0.0.0", PORT), Handler) as server:
        server.serve_forever()
