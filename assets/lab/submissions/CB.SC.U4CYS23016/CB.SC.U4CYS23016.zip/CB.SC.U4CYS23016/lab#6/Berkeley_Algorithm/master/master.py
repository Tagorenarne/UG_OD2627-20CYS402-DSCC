"""Berkeley algorithm - master / coordinator.

1. poll every client for its clock (CLOCK_REQUEST)
2. compute each node's offset relative to the master's clock
3. average the offsets of all participating nodes (master included)
4. send every node the correction  (average - node offset)
5. apply the master's own correction
6. poll again to display and verify the final clocks

Outlier exclusion (OUTLIER_THRESHOLD > 0) is an enhancement and NOT part of
the basic Berkeley algorithm: nodes whose |offset| exceeds the threshold are
left out of the average (they still receive a correction).
"""
import json
import os
import socket
import time
from datetime import datetime, timezone

CLIENTS = [c.strip() for c in os.environ.get(
    "CLIENTS", "clock-client1,clock-client2,clock-client3,clock-client4").split(",") if c.strip()]
CLIENT_PORT = int(os.environ.get("CLIENT_PORT", "5000"))
CLOCK_OFFSET = float(os.environ.get("CLOCK_OFFSET", "0"))            # master's own clock error
OUTLIER_THRESHOLD = float(os.environ.get("OUTLIER_THRESHOLD", "0"))  # seconds, 0 = disabled
POLL_TIMEOUT = float(os.environ.get("POLL_TIMEOUT", "3"))            # per request
STARTUP_TIMEOUT = float(os.environ.get("STARTUP_TIMEOUT", "30"))     # wait for clients to come up

master_offset = CLOCK_OFFSET   # the master's logical clock = system time + this


def master_clock():
    return time.time() + master_offset


def fmt(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).strftime("%H:%M:%S.%f")[:-3]


def exchange(host, message, retry_until=0.0):
    """Send one JSON message to a client; return (reply, t_send, t_recv).

    t_send / t_recv are master-clock readings taken after the connection is
    established, so they bracket only the request/reply itself (DNS and TCP
    setup would otherwise make the round trip asymmetric).
    Raises OSError / ValueError if the client cannot be reached or answers badly.
    """
    while True:
        try:
            with socket.create_connection((host, CLIENT_PORT), timeout=POLL_TIMEOUT) as s:
                t_send = master_clock()
                s.sendall((json.dumps(message) + "\n").encode())
                reply = s.makefile("rb").readline()
                t_recv = master_clock()
            if not reply:
                raise ValueError("empty reply")
            return json.loads(reply), t_send, t_recv
        except (ConnectionError, socket.gaierror) as exc:
            # client container may still be starting: keep retrying until deadline
            if time.time() >= retry_until:
                raise OSError(str(exc)) from exc
            time.sleep(0.5)


def poll(hosts, retry_until=0.0):
    """Berkeley step 1: CLOCK_REQUEST to every node.

    Returns {host: offset_seconds} relative to the master's clock for nodes that
    answered, plus the list of hosts that did not.  The master's clock is read at
    the midpoint of the request/reply round trip, so network delay cancels out.
    """
    offsets, failed = {}, []
    for host in hosts:
        try:
            reply, t_send, t_recv = exchange(host, {"type": "CLOCK_REQUEST"}, retry_until)
            reference = (t_send + t_recv) / 2
            offsets[host] = reply["clock"] - reference
        except (OSError, ValueError, KeyError) as exc:
            print(f"  ! {host} did not respond ({exc})", flush=True)
            failed.append(host)
    return offsets, failed


def label(host):
    return "Master" if host is None else host.replace("clock-", "").replace("client", "Client ")


def show_clocks(title, reference, offsets):
    """Print every node's clock as it reads at the same instant (reference)."""
    print(title + "\n")
    print(f"{'Master':<12} : {fmt(reference)}")
    for host, off in offsets.items():
        print(f"{label(host):<12} : {fmt(reference + off)}")


def rule():
    print("\n" + "-" * 42 + "\n")


def main():
    global master_offset

    print("========== BERKELEY ALGORITHM ==========\n")
    print(f"Clients           : {', '.join(CLIENTS)}")
    print(f"Outlier threshold : "
          f"{'disabled (basic Berkeley)' if OUTLIER_THRESHOLD <= 0 else f'{OUTLIER_THRESHOLD:g} sec (enhancement)'}")
    print()

    # --- Step 1: poll all nodes -------------------------------------------
    reference = master_clock()
    offsets, failed = poll(CLIENTS, retry_until=time.time() + STARTUP_TIMEOUT)
    if not offsets:
        print("No client responded - nothing to synchronize.")
        raise SystemExit(1)

    show_clocks("Initial Clocks", reference, offsets)
    rule()

    # --- Step 2/3: offsets and average ------------------------------------
    print("Clock Offsets\n")
    print(f"{'Master':<12} : {0:+.3f} sec")
    for host, off in offsets.items():
        print(f"{label(host):<12} : {off:+.3f} sec")

    excluded = [h for h, off in offsets.items()
                if OUTLIER_THRESHOLD > 0 and abs(off) > OUTLIER_THRESHOLD]
    used = [0.0] + [off for h, off in offsets.items() if h not in excluded]
    average = sum(used) / len(used)

    print(f"\nAverage Offset: {average:+.3f} sec  "
          f"(over {len(used)} node(s) incl. master)")
    for host in excluded:
        print(f"  * {label(host)} excluded from the average as an outlier "
              f"(|{offsets[host]:+.3f}| > {OUTLIER_THRESHOLD:g} sec)")
    for host in failed:
        print(f"  * {label(host)} did not respond - not part of the synchronization")
    rule()

    # --- Step 4/5: corrections --------------------------------------------
    corrections = {h: average - off for h, off in offsets.items()}
    print("Corrections\n")
    print(f"{'Master':<12} : {average:+.3f} sec")
    for host, corr in corrections.items():
        print(f"{label(host):<12} : {corr:+.3f} sec")
    rule()

    unacked = []
    for host, corr in corrections.items():
        try:
            exchange(host, {"type": "CORRECTION", "value": corr})
        except (OSError, ValueError) as exc:
            print(f"  ! {host} did not acknowledge its correction ({exc})", flush=True)
            unacked.append(host)
    master_offset += average   # the master adjusts its own clock too

    # --- Step 6: verify final clocks --------------------------------------
    reference = master_clock()
    residual, _ = poll([h for h in corrections if h not in unacked])
    show_clocks("Final Clocks", reference, residual)

    print("\nFinal Synchronization Error (relative to master)\n")
    for host, off in residual.items():
        print(f"{label(host):<12} : {off * 1000:+.3f} ms")
    if residual:
        print(f"\nMax error: {max(abs(o) for o in residual.values()) * 1000:.3f} ms")


if __name__ == "__main__":
    main()
