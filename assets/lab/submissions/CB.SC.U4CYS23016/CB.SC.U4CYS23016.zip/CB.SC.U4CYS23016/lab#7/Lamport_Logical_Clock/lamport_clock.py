#!/usr/bin/env python3
"""Lab 7A - Lamport Logical Clock.

Three simulated processes (P1, P2, P3), each with its own integer clock.
    local event : C = C + 1
    send        : C = C + 1, the new C is attached to the message
    receive     : C = max(C, T) + 1      (T = timestamp carried by the message)

Messages are really delivered: send_message() puts the message in the receiver's
inbox and receive_message() takes it out, so the timestamp is transferred from the
sender to the receiver.  Every timestamp is calculated by the rules above.

Besides the clocks, the program records which events are causally related (process
order + send->receive edges).  That "ground truth" is used only to verify
a -> b  =>  L(a) < L(b)  and to find concurrent events; it never feeds the clocks.

Run:  python lamport_clock.py
"""
from __future__ import annotations

import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class Message:
    msg_id: str
    sender: str
    receiver: str
    timestamp: int                       # Lamport timestamp


@dataclass(eq=False)
class Event:
    eid: str                             # E1, E2, ... in execution order
    process: str
    kind: str                            # LOCAL | SEND | RECEIVE
    timestamp: int
    message: Message | None = None
    prev: Event | None = None            # previous event on the same process
    cause: Event | None = None           # RECEIVE only: the matching SEND event


class Process:
    def __init__(self, name: str, system: DistributedSystem):
        self.name = name
        self.system = system
        self.clock = 0
        self.inbox: list[Message] = []
        self.events: list[Event] = []

    def local_event(self) -> Event:
        before = self.clock
        self.clock += 1                                          # Rule 1
        ev = self.system.record(self, "LOCAL", self.clock)
        print(f"  {ev.eid:<4}{self.name}  LOCAL    C = {before} + 1 = {self.clock}")
        return ev

    def send_message(self, receiver: Process) -> Message:
        before = self.clock
        self.clock += 1                                          # Rule 2
        msg = Message(self.system.next_message_id(), self.name, receiver.name, self.clock)
        ev = self.system.record(self, "SEND", self.clock, msg)
        self.system.send_events[msg.msg_id] = ev
        receiver.inbox.append(msg)                               # deliver to the destination
        print(f"  {ev.eid:<4}{self.name}  SEND     C = {before} + 1 = {self.clock}"
              f"   {msg.msg_id}: {msg.sender} -> {msg.receiver}, carries T = {msg.timestamp}")
        return msg

    def receive_message(self, msg: Message) -> Event:
        if msg.receiver != self.name or msg not in self.inbox:
            raise ValueError(f"{self.name} has no pending message {msg.msg_id}")
        self.inbox.remove(msg)
        before = self.clock
        self.clock = max(self.clock, msg.timestamp) + 1          # Rule 3
        ev = self.system.record(self, "RECEIVE", self.clock, msg,
                                cause=self.system.send_events[msg.msg_id])
        print(f"  {ev.eid:<4}{self.name}  RECEIVE  C = max({before}, {msg.timestamp}) + 1 = {self.clock}"
              f"   {msg.msg_id}: {msg.sender} -> {msg.receiver}")
        return ev


class DistributedSystem:
    def __init__(self, names: list[str]):
        self.events: list[Event] = []
        self.messages: list[Message] = []
        self.send_events: dict[str, Event] = {}
        self.processes = {n: Process(n, self) for n in names}

    def next_message_id(self) -> str:
        return f"M{len(self.send_events) + 1}"

    def record(self, process: Process, kind: str, timestamp: int,
               message: Message | None = None, cause: Event | None = None) -> Event:
        ev = Event(f"E{len(self.events) + 1}", process.name, kind, timestamp, message,
                   prev=process.events[-1] if process.events else None, cause=cause)
        self.events.append(ev)
        process.events.append(ev)
        if kind == "SEND":
            self.messages.append(message)
        return ev


# ---------------------------------------------------------------- analysis

def happened_before(a: Event, b: Event) -> bool:
    """Ground truth: is there a chain of process-order / message edges from a to b?"""
    seen, stack = set(), [b]
    while stack:
        e = stack.pop()
        for c in (e.prev, e.cause):
            if c is None or c.eid in seen:
                continue
            if c is a:
                return True
            seen.add(c.eid)
            stack.append(c)
    return False


def relation(a: Event, b: Event) -> str:
    if happened_before(a, b):
        return f"{a.eid} -> {b.eid}"
    if happened_before(b, a):
        return f"{b.eid} -> {a.eid}"
    return "||"


def pairs(events: list[Event]):
    for i, a in enumerate(events):
        for b in events[i + 1:]:
            yield a, b


def banner(title: str) -> None:
    print("=" * 52)
    print(title.center(52))
    print("=" * 52)


def print_event_log(system: DistributedSystem) -> None:
    print()
    banner("LAMPORT LOGICAL CLOCK")
    print(f"\n{'Process':<10} {'Event':<8} {'Type':<10} {'Timestamp':>9}")
    print("-" * 52)
    for e in system.events:
        print(f"{e.process:<10} {e.eid:<8} {e.kind:<10} {e.timestamp:>9}")
    print("-" * 52)
    print("\nFinal clocks: " + ", ".join(f"{p.name} = {p.clock}" for p in system.processes.values()))


def print_messages(system: DistributedSystem) -> None:
    print("\nMessages\n")
    print(f"{'Message ID':<12}{'Sender':<9}{'Receiver':<10}{'Lamport Timestamp':>18}")
    for m in system.messages:
        print(f"{m.msg_id:<12}{m.sender:<9}{m.receiver:<10}{m.timestamp:>18}")


def print_causal_ordering(system: DistributedSystem) -> None:
    print("\n" + "-" * 52)
    print("CAUSAL ORDERING   a -> b  implies  L(a) < L(b)\n")
    rows = []
    for m in system.messages:
        s = system.send_events[m.msg_id]
        r = next(e for e in system.events if e.kind == "RECEIVE" and e.message == m)
        rows.append((f"{s.process} SEND {m.msg_id} ({s.eid})", f"{r.process} RECEIVE {m.msg_id} ({r.eid})", s, r))
    first, last = system.events[0], system.events[-1]
    if happened_before(first, last):          # a transitive chain across all three processes
        rows.append((f"{first.process} {first.kind} ({first.eid})",
                     f"{last.process} {last.kind} ({last.eid})  [transitive]", first, last))
    print(f"{'Event A':<22}{'Event B':<36}{'L(A)':>5}{'L(B)':>6}   L(A) < L(B)")
    for ta, tb, a, b in rows:
        assert happened_before(a, b)
        print(f"{ta:<22}{tb:<36}{a.timestamp:>5}{b.timestamp:>6}   {'yes' if a.timestamp < b.timestamp else 'NO'}")


def print_pair_analysis(system: DistributedSystem) -> None:
    related = concurrent = 0
    misleading, equal = [], []
    for a, b in pairs(system.events):
        if happened_before(a, b) or happened_before(b, a):
            cause, effect = (a, b) if happened_before(a, b) else (b, a)
            assert cause.timestamp < effect.timestamp, "Lamport condition violated"
            related += 1
        else:
            concurrent += 1
            (equal if a.timestamp == b.timestamp else misleading).append((a, b))
    total = related + concurrent
    print("\n" + "-" * 52)
    print(f"ALL {total} EVENT PAIRS CHECKED AGAINST THE SEND/RECEIVE GRAPH\n")
    print(f"  causally related (a -> b)  : {related:>2}   every one has L(a) < L(b)")
    print(f"  concurrent (a || b)        : {concurrent:>2}")
    print(f"      equal timestamps       : {len(equal):>2}")
    print(f"      different timestamps   : {len(misleading):>2}   <- timestamps look ordered, but there is no causality")
    if misleading:
        print(f"\n  {'A':<5}{'B':<5}{'L(A)':>5}{'L(B)':>6}   {'timestamps suggest':<20}truth")
        for a, b in misleading:
            lo, hi = (a, b) if a.timestamp < b.timestamp else (b, a)
            suggests = f"{lo.eid} before {hi.eid}"
            print(f"  {a.eid:<5}{b.eid:<5}{a.timestamp:>5}{b.timestamp:>6}   {suggests:<20}{a.eid} || {b.eid} (concurrent)")


def concurrency_demo() -> None:
    """Part I: two processes that never communicate."""
    print("\n" + "=" * 52)
    print("CONCURRENT EVENTS - P1 and P2 do not communicate".center(52))
    print("=" * 52 + "\n")
    system = DistributedSystem(["P1", "P2"])
    p1, p2 = system.processes["P1"], system.processes["P2"]
    p1.local_event()
    p1.local_event()
    p2.local_event()
    p2.local_event()
    p1_events, p2_events = p1.events, p2.events

    print("\n  P1:  E1 -------- E2")
    print("  P2:  E3 -------- E4        (no message between P1 and P2)\n")
    print(f"  {'A':<5}{'B':<5}{'L(A)':>5}{'L(B)':>6}   relation")
    for a in p1_events:
        for b in p2_events:
            rel = relation(a, b)
            assert rel == "||"
            print(f"  {a.eid:<5}{b.eid:<5}{a.timestamp:>5}{b.timestamp:>6}   {a.eid} || {b.eid}  (concurrent)")

    print("""
Can Lamport timestamps alone determine whether two events are concurrent?

  No.  Lamport clocks guarantee only one direction:

      a -> b   implies   L(a) < L(b)

  The converse does not hold: L(a) < L(b) does NOT imply a -> b.  Above, E2 has
  L = 2 and E3 has L = 1 although neither caused the other, and E1 / E3 even share
  the timestamp 1.  Looking only at the numbers, concurrent events cannot be told
  apart from causally ordered ones (the only safe conclusion is: equal timestamps
  => concurrent, or L(a) > L(b) => NOT a -> b).  Detecting concurrency needs
  vector clocks.""")


def run_scenario() -> DistributedSystem:
    system = DistributedSystem(["P1", "P2", "P3"])
    p1, p2, p3 = (system.processes[n] for n in ("P1", "P2", "P3"))
    print("Initial clocks: " + ", ".join(f"{p.name} = {p.clock}" for p in system.processes.values()) + "\n")

    p1.local_event()                 # 1. P1 local event E1
    m1 = p1.send_message(p2)         # 2. P1 sends a message to P2
    p2.receive_message(m1)           # 3. P2 receives the message from P1
    p2.local_event()                 # 4. P2 local event E4
    m2 = p2.send_message(p3)         # 5. P2 sends a message to P3
    p1.local_event()                 # 6. P1 local event E6
    m3 = p1.send_message(p3)         # 7. P1 sends a message to P3
    p3.receive_message(m2)           # 8. P3 receives the message from P2
    p3.receive_message(m3)           # 9. P3 receives the message from P1
    return system


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    system = run_scenario()
    print_event_log(system)
    print_messages(system)
    print_causal_ordering(system)
    print_pair_analysis(system)
    concurrency_demo()


if __name__ == "__main__":
    main()
