#!/usr/bin/env python3
"""Lab 8B - Vector Clock.

Three simulated processes (P1, P2, P3).  Each keeps a vector of N counters;
position i counts the events of process Pi that this process knows about.
    local event : VC[i] = VC[i] + 1
    send        : VC[i] = VC[i] + 1, a copy of VC is attached to the message
    receive     : VC[j] = max(VC[j], M[j]) for every j, then VC[i] = VC[i] + 1

Messages are really delivered: send_message() puts the message (with its vector) in
the receiver's inbox and receive_message() takes it out.  Every vector is calculated
by the rules above.

For the comparison section each process also keeps a Lamport counter, updated with
the three Lamport rules alongside the vector (it never influences the vector).
A separate "ground truth" (process order + send->receive edges) is used only to
verify that the vector comparison agrees with real causality.

Run:  python vector_clock.py
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from enum import Enum

Vector = tuple[int, ...]


def fmt(v) -> str:
    return "[" + ",".join(str(x) for x in v) + "]"


# ---------------------------------------------------------------- comparison

class Order(Enum):
    BEFORE = "V1 happened before V2"
    AFTER = "V2 happened before V1"
    CONCURRENT = "V1 and V2 are concurrent"
    EQUAL = "V1 and V2 represent the same timestamp"


def order(v1: Vector, v2: Vector) -> Order:
    if len(v1) != len(v2):
        raise ValueError("vectors must have the same length")
    le = all(a <= b for a, b in zip(v1, v2))      # V1 <= V2 component-wise
    ge = all(a >= b for a, b in zip(v1, v2))      # V2 <= V1 component-wise
    if le and ge:
        return Order.EQUAL
    if le:
        return Order.BEFORE                       # <= everywhere, so strictly smaller somewhere
    if ge:
        return Order.AFTER
    return Order.CONCURRENT


def compare_vectors(v1: Vector, v2: Vector) -> str:
    """Part L: the sentence form."""
    return order(v1, v2).value


def compare(v1: Vector, v2: Vector) -> str:
    """Part J: the arrow form  V1 -> V2 | V2 -> V1 | V1 || V2."""
    return {Order.BEFORE: "V1 → V2", Order.AFTER: "V2 → V1",
            Order.CONCURRENT: "V1 || V2", Order.EQUAL: "V1 = V2"}[order(v1, v2)]


def relation(a: Event, b: Event) -> str:
    """Relationship of two events from their vectors: A → B, B → A, A || B (or A = B)."""
    return {Order.BEFORE: "A → B", Order.AFTER: "B → A",
            Order.CONCURRENT: "A || B", Order.EQUAL: "A = B"}[order(a.vector, b.vector)]


def leq_trace(a: Vector, b: Vector) -> str:
    return ", ".join(f"{x} ≤ {y} {'✓' if x <= y else '✗'}" for x, y in zip(a, b))


# ---------------------------------------------------------------- simulation

@dataclass(frozen=True)
class Message:
    msg_id: str
    sender: str
    receiver: str
    vector: Vector                       # vector timestamp
    lamport: int                         # only for the Lamport-vs-vector comparison


@dataclass(eq=False)
class Event:
    eid: str
    process: str
    kind: str                            # LOCAL | SEND | RECEIVE
    vector: Vector
    lamport: int
    message: Message | None = None
    prev: Event | None = None            # previous event on the same process
    cause: Event | None = None           # RECEIVE only: the matching SEND event


class Process:
    def __init__(self, name: str, index: int, system: DistributedSystem):
        self.name, self.index, self.system = name, index, system
        self.vc = [0] * len(system.names)
        self.lamport = 0
        self.inbox: list[Message] = []
        self.events: list[Event] = []

    def local_event(self) -> Event:
        before = fmt(self.vc)
        self.vc[self.index] += 1                                    # Rule 1
        self.lamport += 1
        ev = self.system.record(self, "LOCAL")
        print(f"  {ev.eid:<4}{self.name}  LOCAL    {before} -> {fmt(self.vc)}")
        return ev

    def send_message(self, receiver: Process) -> Message:
        before = fmt(self.vc)
        self.vc[self.index] += 1                                    # Rule 2
        self.lamport += 1
        msg = Message(self.system.next_message_id(), self.name, receiver.name,
                      tuple(self.vc), self.lamport)                 # copy, not a reference
        ev = self.system.record(self, "SEND", msg)
        self.system.send_events[msg.msg_id] = ev
        receiver.inbox.append(msg)                                  # deliver to the destination
        print(f"  {ev.eid:<4}{self.name}  SEND     {before} -> {fmt(self.vc)}"
              f"   {msg.msg_id}: {msg.sender} -> {msg.receiver}, carries {fmt(msg.vector)}")
        return msg

    def receive_message(self, msg: Message) -> Event:
        if msg.receiver != self.name or msg not in self.inbox:
            raise ValueError(f"{self.name} has no pending message {msg.msg_id}")
        self.inbox.remove(msg)
        before = fmt(self.vc)
        merged = [max(a, b) for a, b in zip(self.vc, msg.vector)]   # Rule 3: component-wise max
        merged[self.index] += 1                                     #         then own component + 1
        self.vc = merged
        self.lamport = max(self.lamport, msg.lamport) + 1
        ev = self.system.record(self, "RECEIVE", msg, cause=self.system.send_events[msg.msg_id])
        print(f"  {ev.eid:<4}{self.name}  RECEIVE  max({before}, {fmt(msg.vector)}) + own = {fmt(self.vc)}"
              f"   {msg.msg_id}: {msg.sender} -> {msg.receiver}")
        return ev


class DistributedSystem:
    def __init__(self, names: list[str]):
        self.names = names
        self.events: list[Event] = []
        self.messages: list[Message] = []
        self.send_events: dict[str, Event] = {}
        self.processes = {n: Process(n, i, self) for i, n in enumerate(names)}

    def next_message_id(self) -> str:
        return f"M{len(self.send_events) + 1}"

    def record(self, process: Process, kind: str, message: Message | None = None,
               cause: Event | None = None) -> Event:
        ev = Event(f"E{len(self.events) + 1}", process.name, kind, tuple(process.vc), process.lamport,
                   message, prev=process.events[-1] if process.events else None, cause=cause)
        self.events.append(ev)
        process.events.append(ev)
        if kind == "SEND":
            self.messages.append(message)
        return ev

    def event(self, eid: str) -> Event:
        return next(e for e in self.events if e.eid == eid)


def happened_before(a: Event, b: Event) -> bool:
    """Ground truth: is there a chain of process-order / message edges from a to b?"""
    seen, stack = set(), [b]
    while stack:
        e = stack.pop()
        for c in (e.prev, e.cause):
            if c is None or c.eid in seen:
                continue
            if c is a:
                return True
            seen.add(c.eid)
            stack.append(c)
    return False


# ---------------------------------------------------------------- reports

def rule(char: str = "-", width: int = 56) -> None:
    print(char * width)


def print_event_log(system: DistributedSystem) -> None:
    print()
    rule("=")
    print("VECTOR CLOCK".center(56))
    rule("=")
    print(f"\n{'Process':<10} {'Event':<8} {'Type':<11} Vector Timestamp")
    rule()
    for e in system.events:
        print(f"{e.process:<10} {e.eid:<8} {e.kind:<11} {fmt(e.vector)}")
    rule()
    print("\nFinal vectors: " + ", ".join(f"{p.name} = {fmt(p.vc)}" for p in system.processes.values()))


def print_results_table(system: DistributedSystem) -> None:
    print("\nRESULTS TABLE\n")
    print("| Event | Process | Type | Message | Vector Timestamp |")
    print("|---|---|---|---|---|")
    for e in system.events:
        msg = f"{e.message.sender} → {e.message.receiver}" if e.message else "–"
        print(f"| {e.eid} | {e.process} | {e.kind} | {msg} | {fmt(e.vector)} |")


def print_cases(system: DistributedSystem) -> None:
    ev = system.event
    print("\n" + "=" * 56)
    print("REQUIRED EXPERIMENT".center(56))
    print("=" * 56)

    a, b = ev("E1"), ev("E2")
    print(f"\nCase 1 - same process ordering:  P1 {a.eid} → P1 {b.eid}")
    print(f"  VC({a.eid}) = {fmt(a.vector)}   VC({b.eid}) = {fmt(b.vector)}")
    print(f"  {compare(a.vector, b.vector)}   ({compare_vectors(a.vector, b.vector)})  ->  VC({a.eid}) < VC({b.eid})")

    s = ev("E2")
    r = ev("E3")
    print(f"\nCase 2 - message-based causality:  P1 SEND {s.message.msg_id} ({s.eid}) → P2 RECEIVE {r.message.msg_id} ({r.eid})")
    print(f"  VC(SEND) = {fmt(s.vector)}   VC(RECEIVE) = {fmt(r.vector)}")
    print(f"  {compare(s.vector, r.vector)}   ({compare_vectors(s.vector, r.vector)})  ->  VC(SEND) < VC(RECEIVE)")

    chain = [ev("E2"), ev("E3"), ev("E5"), ev("E8")]
    print("\nCase 3 - transitive causality:  P1 → P2 → P3")
    print("  " + "  →  ".join(f"{e.process} {e.eid} {fmt(e.vector)}" for e in chain))
    for x, y in zip(chain, chain[1:]):
        assert order(x.vector, y.vector) is Order.BEFORE
    first, last = chain[0], chain[-1]
    print(f"  Every step is '<', and end to end: VC({first.eid}) = {fmt(first.vector)}  <  VC({last.eid}) = {fmt(last.vector)}"
          f"   ({compare(first.vector, last.vector)})")
    print(f"  P3 never heard from P1 before {last.eid}, yet its P1 component is {last.vector[0]}: "
          f"the knowledge of {first.eid} travelled through P2.")

    x, y = ev("E6"), ev("E4")
    print(f"\nCase 4 - concurrent events:  P1 {x.eid} and P2 {y.eid}")
    print(f"  A = VC({x.eid}) = {fmt(x.vector)}    B = VC({y.eid}) = {fmt(y.vector)}")
    print(f"  A ≤ B ?  {leq_trace(x.vector, y.vector)}   ->  A ≰ B")
    print(f"  B ≤ A ?  {leq_trace(y.vector, x.vector)}   ->  B ≰ A")
    print(f"  Neither is smaller:  {x.eid} || {y.eid}   ({compare_vectors(x.vector, y.vector)})")
    assert order(x.vector, y.vector) is Order.CONCURRENT and not happened_before(x, y) and not happened_before(y, x)


def print_relationship_table(system: DistributedSystem) -> None:
    print("\n" + "-" * 56)
    print("CAUSAL RELATIONSHIP TABLE\n")
    print("| Event A | Event B | Vector A | Vector B | Relationship |")
    print("|---|---|---|---|---|")
    for ea, eb in [("E1", "E2"), ("E2", "E3"), ("E5", "E8"), ("E6", "E4"), ("E7", "E5")]:
        a, b = system.event(ea), system.event(eb)
        rel = relation(a, b).replace("A", ea).replace("B", eb)
        print(f"| {ea} | {eb} | {fmt(a.vector)} | {fmt(b.vector)} | {rel} |")


def print_verification(system: DistributedSystem) -> None:
    events = system.events
    symbol = {Order.BEFORE: "<", Order.AFTER: ">", Order.CONCURRENT: "||", Order.EQUAL: "="}
    print("\n" + "-" * 56)
    print("RELATION MATRIX (row event vs column event)   < before   > after   || concurrent\n")
    print("      " + "".join(f"{e.eid:>4}" for e in events))
    related = concurrent = 0
    for a in events:
        cells = []
        for b in events:
            o = order(a.vector, b.vector)
            truth_before, truth_after = happened_before(a, b), happened_before(b, a)
            expected = (Order.EQUAL if a is b else Order.BEFORE if truth_before
                        else Order.AFTER if truth_after else Order.CONCURRENT)
            assert o is expected, f"vector clock disagrees with ground truth for {a.eid}, {b.eid}"
            cells.append(f"{symbol[o]:>4}")
        print(f"{a.eid:>4}  " + "".join(cells))
    for i, a in enumerate(events):
        for b in events[i + 1:]:
            if order(a.vector, b.vector) is Order.CONCURRENT:
                concurrent += 1
            else:
                related += 1
    total = related + concurrent
    print(f"\nVerified against the send/receive graph for all {total} pairs: "
          f"{related} causally related, {concurrent} concurrent - vector comparison is exact.")


def print_lamport_comparison(system: DistributedSystem) -> None:
    print("\n" + "-" * 56)
    print("LAMPORT vs VECTOR (same events)\n")
    print(f"{'Event':<7}{'Process':<9}{'Lamport':>8}   Vector")
    for e in system.events:
        print(f"{e.eid:<7}{e.process:<9}{e.lamport:>8}   {fmt(e.vector)}")

    bad = [(a, b) for i, a in enumerate(system.events) for b in system.events[i + 1:]
           if order(a.vector, b.vector) is Order.CONCURRENT and a.lamport != b.lamport]
    print(f"\nConcurrent pairs whose Lamport timestamps nevertheless differ ({len(bad)}):\n")
    print(f"  {'A':<5}{'B':<5}{'Lamport A':>10}{'Lamport B':>10}   {'Vector A':<11}{'Vector B':<11}vector says")
    for a, b in bad:
        print(f"  {a.eid:<5}{b.eid:<5}{a.lamport:>10}{b.lamport:>10}   {fmt(a.vector):<11}{fmt(b.vector):<11}"
              f"{a.eid} || {b.eid}")
    print("\nLamport timestamps order these pairs although neither event caused the other;"
          "\nthe vectors show that they are concurrent.")


def run_scenario() -> DistributedSystem:
    system = DistributedSystem(["P1", "P2", "P3"])
    p1, p2, p3 = (system.processes[n] for n in ("P1", "P2", "P3"))
    print("Initial vectors: " + ", ".join(f"{p.name} = {fmt(p.vc)}" for p in system.processes.values()) + "\n")

    p1.local_event()                 # 1. P1 local event E1
    m1 = p1.send_message(p2)         # 2. P1 sends M1 to P2
    p2.receive_message(m1)           # 3. P2 receives M1
    p2.local_event()                 # 4. P2 local event E4
    m2 = p2.send_message(p3)         # 5. P2 sends M2 to P3
    p1.local_event()                 # 6. P1 local event E6
    m3 = p1.send_message(p3)         # 7. P1 sends M3 to P3
    p3.receive_message(m2)           # 8. P3 receives M2
    p3.receive_message(m3)           # 9. P3 receives M3
    return system


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    system = run_scenario()
    print_event_log(system)
    print_results_table(system)
    print_cases(system)
    print_relationship_table(system)
    print_verification(system)
    print_lamport_comparison(system)


if __name__ == "__main__":
    main()
