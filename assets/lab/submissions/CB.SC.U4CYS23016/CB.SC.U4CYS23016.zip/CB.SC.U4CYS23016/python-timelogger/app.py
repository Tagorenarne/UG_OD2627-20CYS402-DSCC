import time
from datetime import datetime

LOG_FILE = "/app/logs/logs.txt"

def write_log():
    while True:
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a") as f:
            f.write(f"Log entry at: {current_time}\n")
            f.flush()  # ensures it's written to disk immediately
        time.sleep(5)

if __name__ == "__main__":
    write_log()